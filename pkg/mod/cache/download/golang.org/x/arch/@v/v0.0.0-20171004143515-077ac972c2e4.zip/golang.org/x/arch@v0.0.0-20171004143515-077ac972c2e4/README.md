# arch

This repository holds machine architecture information used by the Go toolchain.
The parts needed in the main Go repository are copied in.

This repository requires Go 1.5+ with the vendor experiment enabled.
